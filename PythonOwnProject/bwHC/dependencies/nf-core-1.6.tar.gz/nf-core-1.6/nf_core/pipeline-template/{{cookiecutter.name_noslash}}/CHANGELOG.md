# {{ cookiecutter.name }}: Changelog

## v{{ cookiecutter.version }} - [date]
Initial release of {{ cookiecutter.name }}, created with the [nf-core](http://nf-co.re/) template.
