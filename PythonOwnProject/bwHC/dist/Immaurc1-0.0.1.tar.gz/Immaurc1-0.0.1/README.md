# Full REST API for bwHC

You can use that for rest testing in your own development system.
